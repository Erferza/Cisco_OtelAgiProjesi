module com.example.proje {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.proje to javafx.fxml;
    exports com.example.proje;
}