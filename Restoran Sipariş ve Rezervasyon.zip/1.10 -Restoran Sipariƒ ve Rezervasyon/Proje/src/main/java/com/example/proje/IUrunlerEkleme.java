package com.example.proje;

public interface IUrunlerEkleme {
    void urunEkle(String ad, double fiyat);
}
