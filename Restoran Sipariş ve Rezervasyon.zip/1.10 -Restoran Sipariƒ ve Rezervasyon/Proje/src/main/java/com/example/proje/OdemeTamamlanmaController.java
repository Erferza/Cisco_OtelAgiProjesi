package com.example.proje;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class OdemeTamamlanmaController extends UyariGostermeSayfaYukleme{
    @FXML
    private Button anaSayfaButton;
    @FXML
    private Button CikisBtn;
    @FXML
    private void onGeriButonClicked() {
        sayfaYukleme("Hos_Geldin.fxml",anaSayfaButton);
    }
    @FXML
    private void onCikisBtnClicked(){
        sayfaYukleme("Giris_Ekrani.fxml",CikisBtn);
    }
}
