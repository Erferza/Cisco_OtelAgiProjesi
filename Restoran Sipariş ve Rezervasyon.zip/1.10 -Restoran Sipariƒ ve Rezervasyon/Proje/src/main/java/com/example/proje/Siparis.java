package com.example.proje;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class Siparis extends Sepet {
    @FXML
    private ChoiceBox<Yemek> yemekChoiceBox; //Kullanıcının yemek seçimi yapması için bir seçenek kutusu.

    @FXML
    private ChoiceBox<Icecek> icecekChoiceBox; //Kullanıcının içecek seçimi yapması için bir seçenek kutusu.

    @FXML
    private ChoiceBox<Integer> yemekAdetChoiceBox; //Kullanıcının yemek adedi seçmesi için bir seçenek kutusu.

    @FXML
    private ChoiceBox<Integer> icecekAdetChoiceBox; //Kullanıcının içecek adedi seçmesi için bir seçenek kutusu.

    @FXML
    private Button ekleButton;// Seçilen ürünlerin sepete eklenmesi için kullanılan buton.

    @FXML
    private ImageView geriButon; //Bir önceki sayfaya geri dönenmesini sağlar

    @FXML
    private Button siparisButton; // Siparişi tamamlamak ve sepet sayfasına gitmek için kullanılan buton
    @FXML
    private Button CikisBtn; // Oturum kapatma buton

    @FXML
    public void initialize() { //Ekran yüklendiğinde varsayılan ayarların yapılması için kullanılan yöntem.
        ObservableList<Yemek> yemekListesi = AdminYemekEklemeSayfaController.getYemekListesi(); //Yemek listesini alır.
        ObservableList<Icecek> icecekListesi = AdminIcecekEklemeSayfaController.getIcecekListesi(); //İçecek listesini alır.
        yemekChoiceBox.setItems(yemekListesi);//Yemek seçme kutusuna içecek listesini ekler.
        icecekChoiceBox.setItems(icecekListesi);//İçecek seçme kutusuna içecek listesini ekler.
        //Yemek ve içecek adetleri için seçim kutusuna 1'den 20'ye kadar değerler eklenir.
        yemekAdetChoiceBox.setItems(FXCollections.observableArrayList(1,2,3,4,5));
        icecekAdetChoiceBox.setItems(FXCollections.observableArrayList(1,2,3,4,5));

        // ekleButton yalnızca hem yemek hem içecek seçilmediğinde ya da miktar belirlenmediğinde devre dışı olur.
        ekleButton.disableProperty().bind(
                yemekChoiceBox.valueProperty().isNull().and(icecekChoiceBox.valueProperty().isNull())
                        .or(yemekAdetChoiceBox.valueProperty().isNull().and(icecekAdetChoiceBox.valueProperty().isNull()))
        );
    }

    @FXML
    private void ekle() {//Yemek veya içecek seçimi yapıldığında ürünü sepete ekleme yapan metod.
        if (yemekChoiceBox.getValue() != null && yemekAdetChoiceBox.getValue() != null) {
            Yemek secilenYemek = yemekChoiceBox.getValue();//Seçilen yemek.
            int yemekAdet = yemekAdetChoiceBox.getValue(); //Seçilen yemek adedi.
            urunEkle(new Menu(secilenYemek.getIsim(), yemekAdet, secilenYemek.getFiyat() * yemekAdet));// Seçilen yemeği sepete ekler.
            System.out.println("Yemek eklendi: " + secilenYemek.getIsim());// Konsola bilgi yazdırır.
            uyariGoster("Başarılı", secilenYemek.getIsim() + " Başarıyla Eklendi", 1);

        }

        if (icecekChoiceBox.getValue() != null && icecekAdetChoiceBox.getValue() != null) {
            Icecek secilenIcecek = icecekChoiceBox.getValue();//Seçilen içecek.
            int icecekAdet = icecekAdetChoiceBox.getValue(); //Seçilen içecek adedi.
            urunEkle(new Menu(secilenIcecek.getIsim(), icecekAdet, secilenIcecek.getFiyat() * icecekAdet));// Seçilen içeceği sepete ekler.
            System.out.println("İçecek eklendi: " + secilenIcecek.getIsim());// Konsola bilgi yazdırır.
            uyariGoster("Başarılı", secilenIcecek.getIsim() + " Başarıyla Eklendi", 1);

        }
        // Seçimleri sıfırla
        yemekChoiceBox.setValue(null);
        yemekAdetChoiceBox.setValue(null);
        icecekChoiceBox.setValue(null);
        icecekAdetChoiceBox.setValue(null);
    }


    @FXML
    private void onGeriButonClicked() {
        sayfaYukleme("Hos_Geldin.fxml",geriButon);
    }

    @FXML
    private void siparisVer(){
        sayfaYukleme("Sepet.fxml",siparisButton);
    }
    @FXML
    private void onCikisBtnClicked(){
        sayfaYukleme("Giris_Ekrani.fxml",CikisBtn);
    }

}
