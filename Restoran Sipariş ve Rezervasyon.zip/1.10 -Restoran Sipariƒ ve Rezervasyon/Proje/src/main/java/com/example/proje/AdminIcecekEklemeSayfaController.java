package com.example.proje;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

import java.io.IOException;

public class AdminIcecekEklemeSayfaController extends UyariGostermeSayfaYukleme implements IUrunlerEkleme {
    @FXML
    private TextField IcecekAd; //Yazılan içecek adın texti
    @FXML
    private TextField IcecekFiyat;//Yazılan içeceğin fiyat texti
    @FXML
    private Button IcecekEklemeBtn; //İçecek Ekleme Butonu
    @FXML
    private Button CikisBtn; //Oturum Kapatma Butonu
    @FXML
    private ImageView geriButon; //Admin ana sayfaya dönme image
    @FXML
    private Button YemekSayfaBtn; //Yemek sayfasına dönme butonu

    //Girilen içeceklerin listesi (ObservableList)
    private static final ObservableList<Icecek> icecekListesi = FXCollections.observableArrayList();
    @FXML //İçecek ekleme butonuna tıklayınca içecek ekleyen metot
    private void onIcecekEklemeBtnClicked() {
        String icecekAdi = IcecekAd.getText();//İçecek adı alıyor
        String icecekFiyati = IcecekFiyat.getText();//İçecek fiyat alıyor
        if (icecekAdi.isEmpty() || icecekFiyati.isEmpty()) { //Eğer textfieldler boşsa hata veriyor
            uyariGoster("Hata", "Lütfen tüm alanları doldurunuz!",2);
            return;
        }
        try {
            double fiyat = Double.parseDouble(icecekFiyati);//stringi double a çeviriyor.
            //Eğer harf girildiyse catch e atıyor. Hata kontrolü
            urunEkle(icecekAdi, fiyat);//urunu ekliyor
            uyariGoster("Başarılı", "İçecek başarıyla eklendi!",1);//Her şey düzgünse Başarılı mesajı veriyor.
            IUrun icecek = new Icecek(icecekAdi, fiyat);//Polimorfizm. Konsolda yazdırma
            System.out.println(icecek.getIsim() + " : " + icecek.getFiyat() + " olarak ayarlanmıştır.");
            //Değer girildikten textfieldlar siliniyor.
            IcecekAd.clear();
            IcecekFiyat.clear();
        } catch (NumberFormatException e) {
            //Harf girerse bu catche atıyor atıyor.
            uyariGoster("Hata", "Fiyat alanına geçerli bir sayı giriniz!",2);
        }
    }

    //Yeni bir içecek eklemek için kullanılan metot (Interface üzerinden override ediliyor)
    @Override
    public void urunEkle(String ad, double fiyat) {
        icecekListesi.add(new Icecek(ad, fiyat));
    }

    //İçecek listesini döndüren metot
    public static ObservableList<Icecek> getIcecekListesi() {
        return icecekListesi;
    }

    @FXML//Çıkış Butonu tıklandığında giriş sayfasına giden metot.
    private void onCikisBtnClicked() throws IOException {
        sayfaYukleme("Giris_Ekrani.fxml",CikisBtn);
    }
    @FXML//Geri image tıklandığında bir admin ana sayfaya giden metot.
    private void onGeriButonClicked() {
        sayfaYukleme("AdminAnaSayfa.fxml", geriButon);
    }
    @FXML//Yemek Ekleme Butonu tıklandığında yemek ekleme sayfasına giden metot.
    private void onYemekSayfaButonClicked() {
        sayfaYukleme("AdminYemekEklemeSayfa.fxml", YemekSayfaBtn);
    }
}
