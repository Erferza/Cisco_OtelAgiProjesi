package com.example.proje;

import java.util.ArrayList;

public abstract class Kullanicilar {
    public String ad, soyad, kAdi, sifre;
    static ArrayList<Kullanicilar> kullanicilar = new ArrayList<>();

    public Kullanicilar(String ad, String soyad, String kAdi, String sifre) {
        this.ad = ad;
        this.soyad = soyad;
        this.kAdi = kAdi;
        this.sifre = sifre;
    }

    public String getAd() {

        return ad;
    }

    public String getSoyad() {

        return soyad;
    }

    public String getkAdi() {

        return kAdi;
    }

    public String getSifre() {

        return sifre;
    }

    // Alt sınıfların bu metodu implemente etmesi gerekecek
    public abstract String getRol();
}
