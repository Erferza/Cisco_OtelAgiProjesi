package com.example.proje;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

public class RezervasyonController extends UyariGostermeSayfaYukleme {
    //Tarih seçmek için kullanılan bileşen
    @FXML
    private DatePicker tarihSecici;

    //Saat seçimi için kullanılan bileşen
    @FXML
    private ChoiceBox<String> saatSecici;

    //Masa butonları, her biri farklı bir masa temsil eder
    @FXML
    private Button masa1Butonu;
    @FXML
    private Button masa2Butonu;
    @FXML
    private Button masa3Butonu;

    //Geri ve Çıkış butonları
    @FXML
    private ImageView geriButon;
    @FXML
    private Button CikisBtn;

    //Uygun saatler listesi
    private ObservableList<String> uygunSaatler = FXCollections.observableArrayList(
            "18:00", "19:00", "20:00", "21:00", "22:00", "23:00"
    );

    //Tarih seçiminin başlangıcı ve bitişi
    private LocalDate baslangicTarihi;
    private LocalDate bitisTarihi;

    //Rezervasyonları depolamak için kullanılan bir harita
    //Anahtar: Tarih + Saat, Değer: Masa
    private Map<String, String> rezervasyonlar = new HashMap<>();

    @FXML
    public void initialize() {
        // Başlangıç ve bitiş tarihlerini bugünden itibaren 3 gün olarak ayarla
        baslangicTarihi = LocalDate.now();
        bitisTarihi = baslangicTarihi.plus(3, ChronoUnit.DAYS);

        //Tarih seçicide sadece belirlenen aralıktaki tarihlerin seçilebilmesi için kısıtlama ekle
        tarihSecici.setDayCellFactory(picker -> new javafx.scene.control.DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isBefore(baslangicTarihi) || date.isAfter(bitisTarihi));
            }
        });

        //Uygun saatler ChoiceBox'a eklenir
        saatSecici.setItems(uygunSaatler);
        saatSecici.setDisable(true); // Saat seçimi başlangıçta devre dışıdır

        //Masa butonları başlangıçta devre dışı
        masa1Butonu.setDisable(true);
        masa2Butonu.setDisable(true);
        masa3Butonu.setDisable(true);

        //Tarih seçildiğinde saat seçimini etkinleştir
        tarihSecici.setOnAction(event -> {
            if (tarihSecici.getValue() != null) {
                saatSecici.setDisable(false);
            } else {
                saatSecici.setDisable(true);
                masa1Butonu.setDisable(true);
                masa2Butonu.setDisable(true);
                masa3Butonu.setDisable(true);
            }
        });

        //Saat seçildiğinde masa seçimlerini etkinleştir
        saatSecici.setOnAction(event -> {
            if (saatSecici.getValue() != null) {
                masa1Butonu.setDisable(false);
                masa2Butonu.setDisable(false);
                masa3Butonu.setDisable(false);
            } else {
                masa1Butonu.setDisable(true);
                masa2Butonu.setDisable(true);
                masa3Butonu.setDisable(true);
            }
        });
    }

    //Masa 1 için rezervasyon yapar
    @FXML
    private void masa1RezerveEt(ActionEvent event) {
        rezervasyonYap("Masa 1");
    }

    //Masa 2 için rezervasyon yapar
    @FXML
    private void masa2RezerveEt(ActionEvent event) {
        rezervasyonYap("Masa 2");
    }

    //Masa 3 için rezervasyon yapar
    @FXML
    private void masa3RezerveEt(ActionEvent event) {
        rezervasyonYap("Masa 3");
    }

    //Rezervasyon işlemini gerçekleştiren yardımcı metod
    private void rezervasyonYap(String masaAdi) {
        //Seçilen tarih ve saat alınır
        LocalDate secilenTarih = tarihSecici.getValue();
        String secilenSaat = saatSecici.getValue();

        //Eğer tarih seçilmediyse uyarı göster
        if (secilenTarih == null) {
            uyariGoster("Hata", "Lütfen bir tarih seçin.", 2);
            return;
        }

        //Eğer saat seçilmediyse uyarı göster
        if (secilenSaat == null) {
            uyariGoster("Hata", "Lütfen bir saat seçin.", 2);
            return;
        }

        //Anahtar oluştur (Tarih + Saat)
        String anahtar = secilenTarih.toString() + " " + secilenSaat;

        //Eğer bu anahtar için rezervasyon varsa hata göster
        if (rezervasyonlar.containsKey(anahtar)) {
            uyariGoster("Hata", "Bu tarih ve saat için zaten bir masa rezerve edilmiş.", 2);
            return;
        }

        //Rezervasyonu haritaya ekle
        rezervasyonlar.put(anahtar, masaAdi);

        //Başarılı mesaj göster
        String mesaj = String.format("Rezervasyon başarılı!\nMasa: %s\nTarih: %s\nSaat: %s", masaAdi, secilenTarih, secilenSaat);
        uyariGoster("Rezervasyon Onaylandı", mesaj, 1);
    }

    @FXML
    private void onGeriButonClicked() {
        sayfaYukleme("Hos_Geldin.fxml", geriButon);
    }

    @FXML
    private void onCikisBtnClicked() {
        sayfaYukleme("Giris_Ekrani.fxml", CikisBtn);
    }
}
