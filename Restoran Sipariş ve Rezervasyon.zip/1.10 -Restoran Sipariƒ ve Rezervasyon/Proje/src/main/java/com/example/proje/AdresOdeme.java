package com.example.proje;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class AdresOdeme extends UyariGostermeSayfaYukleme implements IKontrol{

    @FXML
    private TextField adSoyad; //ad soyad için textfield

    @FXML
    private TextField adresBilgileri; //adres için texfield

    @FXML
    private TextField kartNumarasi; //Kart numarası için textfield

    @FXML
    private TextField cvv; //Cvv için textfield

    @FXML
    private ChoiceBox<String> aySecimi; //ChoiceBox (1-12 kadar aylar var)

    @FXML
    private ChoiceBox<String> yilSecimi; //ChoiceBox(23-30 yılları arası var)

    @FXML
    private Label ToplamTutarLabel; //Toplam fiyatı gösteren yazi

    @FXML
    private ImageView geriButon; //Bir önceki sayfa dönme image

    @FXML
    private Button odemeYapButonu; //Ödeme yapma butonu
    @FXML
    private Button CikisBtn;//Oturum Kapatma Butonu
    @Override
    public boolean bosluk_hata_kontrol(){
        //Tüm alanların doğru şekilde doldurulup doldurulmadığını kontrol eder
        if(!adSoyad.getText().isEmpty() //Ad soyad boş değilse
                && !adresBilgileri.getText().isEmpty() //adres bilgisi boş değilse
                && kartNumarasi.getText().replaceAll(" ", "").length() == 16 //Adres bilgisi boş değilse ve uzunluk 16 ya eşitse
                && cvv.getText().length() == 3 //CVV 3 haneli ise
                && aySecimi.getValue() != null //Ay seçilmişse
                && yilSecimi.getValue() != null) //Yıl seçilmişse
            return true;
        else
            return false;
    }
    @FXML
    public void initialize() {
        //Ay seçimlerini ChoiceBoxa ekleme (01-12)
        aySecimi.getItems().addAll("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12");

        // Yıl seçimlerini ChoiceBoxa ekleme (2024-2030)
        for (int yil = 2024; yil <= 2030; yil++) {
            yilSecimi.getItems().add(String.valueOf(yil));
        }

        //Varsayılan ay ve yıl değerlerini ayarlama
        aySecimi.setValue("01");
        yilSecimi.setValue("2024");

        //Ad soyad giriş kontrolü. Sadece harf ve boşluk izin veriliyor.
        adSoyad.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (!newValue.matches("[a-zA-Z\\u00C0-\\u017F ]*")) {
                    adSoyad.setText(newValue.replaceAll("[^a-zA-Z\\u00C0-\\u017F ]", ""));
                }
                kontrolEt();
            }
        });

        //Kart numarası giriş kontrolü. Sadece rakam ve dörtlü grup
        kartNumarasi.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                newValue = newValue.replaceAll("\\D", "");
                if (newValue.length() > 16) {
                    newValue = newValue.substring(0, 16);
                }
                StringBuilder formatted = new StringBuilder();
                for (int i = 0; i < newValue.length(); i++) {
                    if (i > 0 && i % 4 == 0) {
                        formatted.append(" ");
                    }
                    formatted.append(newValue.charAt(i));
                }
                kartNumarasi.setText(formatted.toString());
                kontrolEt();
            }
        });

        //CVV giriş kontrolü. Sadece 3 haneli rakam
        cvv.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (!newValue.matches("\\d*")) {
                    cvv.setText(newValue.replaceAll("\\D", ""));
                }
                if (newValue.length() > 3) {
                    cvv.setText(newValue.substring(0, 3));
                }
                kontrolEt();
            }
        });

        //Adres bilgileri giriş kontrolü
        adresBilgileri.textProperty().addListener((observable, oldValue, newValue) -> kontrolEt());

        //Ay ve yıl seçimleri değiştiğinde kontrol
        aySecimi.valueProperty().addListener((observable, oldValue, newValue) -> kontrolEt());
        yilSecimi.valueProperty().addListener((observable, oldValue, newValue) -> kontrolEt());

    }

    private void kontrolEt() {
        //Ödeme yap butonunu yalnızca tüm alanlar doğru doldurulmuşsa butonu etkinleştiren metot
        boolean butonAktif = bosluk_hata_kontrol();
        odemeYapButonu.setDisable(!butonAktif);
    }

    //Toplam tutar etiketini güncelleyen metot
    public void setToplamTutarLabel(double fiyat) {

        this.ToplamTutarLabel.setText("Toplam Tutar: " + fiyat + "₺");
    }

    @FXML
    private void onGeriButonClicked() {//Geri image tıklandığında bir önceki sayfaya giden metot.
        sayfaYukleme("Sepet.fxml",geriButon);
    }

    @FXML
    private void islemiTamamla() { // Kullanıcının ödeme bilgilerini işler ve konsola yazdırmaya sağlayan metot

        String adSoyadDegeri = adSoyad.getText();
        String adresBilgileriDegeri = adresBilgileri.getText();
        String kartNumarasiDegeri = kartNumarasi.getText();
        String cvvDegeri = cvv.getText();
        String secilenAy = aySecimi.getValue();
        String secilenYil = yilSecimi.getValue();

        System.out.println("Ad Soyad: " + adSoyadDegeri);
        System.out.println("Adres Bilgileri: " + adresBilgileriDegeri);
        System.out.println("Kart Numarası: " + kartNumarasiDegeri);
        System.out.println("CVV: " + cvvDegeri);
        System.out.println("Son Kullanma Tarihi: " + secilenAy + "/" + secilenYil);

        //Ödeme işlemini tamamlama mesajı
        System.out.println("Ödeme işlemi tamamlandı!");
    }

    @FXML
    private void onOdemeYapButonuClicked() {
        //Ödeme yap butonuna basıldığında ödeme tamamlandı sayfasına atcak
        islemiTamamla();
        sayfaYukleme("OdemeTamamlanma.fxml",odemeYapButonu);
    }
    @FXML
    private void onCikisBtnClicked() throws IOException {//Çıkış Butonu tıklandığında giriş sayfasına giden metot.
        sayfaYukleme("Giris_Ekrani.fxml",CikisBtn);
    }
}
