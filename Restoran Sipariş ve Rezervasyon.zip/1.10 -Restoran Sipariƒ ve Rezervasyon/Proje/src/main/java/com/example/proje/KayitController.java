package com.example.proje;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class KayitController extends UyariGostermeSayfaYukleme implements IKontrol{
    @FXML
    private TextField adTxt;//Kullanıcı adi için text field
    @FXML
    private TextField soyadTxt;//Kullanıcı soyad için text field
    @FXML
    private TextField kAdiTxt; //Kullanıcı adı için text field
    @FXML
    private PasswordField sifrePw;//Şifre için şifre alanı
    @FXML
    private PasswordField sifrePw2;//Şifre tekrar için şifre alanı
    @FXML
    private ImageView geriButon; //Giriş sayfaya dönme image
    @FXML
    private Button kayitButon; //Kayıt olma butonu
    @Override
    public boolean bosluk_hata_kontrol(){ //Tüm metin alanlarının boş olup olmadığını kontrol eder
        if(kAdiTxt.getText().isEmpty() ||adTxt.getText().isEmpty() ||soyadTxt.getText().isEmpty() ||sifrePw.getText().isEmpty() ||sifrePw2.getText().isEmpty()) {
            return true;//Eğer bir alan boşsa true(hata) döner
        }
        else{
            return false;//Eğer bir alan dolu ise false döner. Hata yoktur
        }
    }
    @FXML
    private void onGeriButonClicked() { //Geri image tıklandığında bir giriş sayfasına giden metot.
        sayfaYukleme("Giris_Ekrani.fxml",geriButon);
    }
    @FXML
    private void onKayitButonClicked(){ //Kayıt olma butonuna tıklanınca çalışan metot
        for(Kullanicilar kullanicilar1 : Kullanicilar.kullanicilar)
        {
            System.out.println(kullanicilar1.getkAdi());
        }
        if(bosluk_hata_kontrol()) {
            uyariGoster("Hatalı Giriş", "Hiçbir kutucuğu boş bırakmayınız!",2);

        }
        else {
            String ad = adTxt.getText();
            String soyad = soyadTxt.getText();
            String kAdi = kAdiTxt.getText();
            String sifre1 = sifrePw.getText();
            String sifre2 = sifrePw2.getText();
            boolean kayit = false;
            for (Kullanicilar kullanicilar1 : Kullanicilar.kullanicilar) {
                if(kAdi.equals(kullanicilar1.getkAdi()))
                {
                    kayit=true;
                    break;
                }
            }
            if(kayit)
            {
                uyariGoster("Var Olan Kullanı Hatası", "Bu kullanıcı ismi daha önce alınmıştır!",2);
            }
            else {
                if(sifre1.equals(sifre2))
                {
                    Kullanicilar.kullanicilar.add(new Musteri(ad,soyad,kAdi,sifre1));
                    uyariGoster("Kayıt Olundu!", "Başarıyla kayıt oldunuz!",1);
                    sayfaYukleme("Giris_Ekrani.fxml",geriButon);
                }
                else {
                    uyariGoster("Şifre Hatası", "Şifreler uyuşmamaktadır",2);
                }
            }
        }
    }

}
