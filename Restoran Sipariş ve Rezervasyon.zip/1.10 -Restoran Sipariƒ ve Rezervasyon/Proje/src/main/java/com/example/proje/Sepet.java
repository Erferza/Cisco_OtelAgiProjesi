package com.example.proje;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Sepet extends UyariGostermeSayfaYukleme {

    //Sepet listesi, sepetteki ürünleri tutar. Static olarak tanımlandığı için uygulama genelinden erişilebilir.
    protected static ObservableList<Menu> sepetListesi = FXCollections.observableArrayList();

    //Sepetteki ürünlerin toplam fiyatını tutar. Static olduğu için tüm sınıflarda paylaşılan bir değer.
    protected static double genelToplamFiyat = 0.0;

    public void urunEkle(Menu urun) {
        //Sepete yeni bir ürün ekler ya da aynı ürün varsa sadece adedini artırır.
        boolean urunZatenSepette = false; //Ürünün sepette olup olmadığını kontrol etmek için bir bayrak.
        //Sepette aynı üründen varsa adet artırılır.
        for (Menu mevcutUrun : sepetListesi) {
            if (mevcutUrun.getUrunAdi().equals(urun.getUrunAdi())) {
                //Ürünün adı aynı ise adedi artır ve döngüden çık.
                mevcutUrun.setAdet(mevcutUrun.getAdet() + urun.getAdet());
                urunZatenSepette = true;
                break;
            }
        }

        if (!urunZatenSepette) {
            //Eğer ürün sepette yoksa doğrudan sepete ekle.
            sepetListesi.add(urun);
        }

        //Ürünün fiyatını genel toplam fiyata ekle.
        genelToplamFiyat += urun.getFiyat();

        //Konsola bilgi yazdır.
        System.out.println("Ürün eklendi: " + urun.getUrunAdi());
        System.out.println("Genel Toplam Fiyat: " + genelToplamFiyat);
    }

    public void urunSil(Menu urun) {
        //Sepetten bir ürün siler.

        if (sepetListesi.contains(urun)) {
            //Ürün sepette varsa listeden çıkar.
            sepetListesi.remove(urun);

            //Ürünün fiyatını genel toplam fiyattan çıkar.
            genelToplamFiyat -= urun.getFiyat();
        }
    }

    public double getGenelToplamFiyat() {
        //Genel toplam fiyatı döner.
        return genelToplamFiyat;
    }

    public ObservableList<Menu> getSepetListesi() {
        //Sepet listesini döner.
        return sepetListesi;
    }
}
