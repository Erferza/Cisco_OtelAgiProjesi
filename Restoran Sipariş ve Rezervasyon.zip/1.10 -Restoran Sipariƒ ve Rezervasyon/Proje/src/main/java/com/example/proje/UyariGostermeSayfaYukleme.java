package com.example.proje;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;
import java.io.IOException;
import javafx.scene.control.Alert;

public abstract class UyariGostermeSayfaYukleme {
    //Uyarı-Bilgi göstermek için kullanılan metot(Başarılı veya hata mesajları için)
    protected void uyariGoster(String baslik, String mesaj,int hata_durum) {
        Alert.AlertType alertType;
        if (hata_durum == 1) {
            alertType = Alert.AlertType.INFORMATION;
        } else {
            alertType = Alert.AlertType.ERROR;
        }
        Alert alert = new Alert(alertType);
        alert.setTitle(baslik);
        alert.setHeaderText(null);
        alert.setContentText(mesaj);
        alert.showAndWait();
    }
    //Sayfa geçişleri için kullanılan metot
    protected void sayfaYukleme(String fxmlDosya, Button buton){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlDosya));
            Parent root = loader.load();
            Stage stage = (Stage) buton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();//Konsola hatayı yazar
        }
    }
    //Sayfa geçişleri için kullanılan metot (Resim olursa) - Overloading
    protected void sayfaYukleme(String fxmlDosya, ImageView butonResim) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlDosya));
            Parent root = loader.load();
            Stage stage = (Stage) butonResim.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //Sayfa geçişleri için kullanılan metot - (Sipariş sayfası için özel)
    protected void sayfaYukleme(String fxmlDosya, Button buton, Double metod ){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlDosya));
            Parent root = loader.load();
            AdresOdeme adresOdeme = loader.getController();
            adresOdeme.setToplamTutarLabel(metod);
            Stage stage = (Stage) buton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();//Konsola hatayı yazar
        }
    }

}
