package com.example.proje;

class Musteri extends Kullanicilar {
    public Musteri(String ad, String soyad, String kAdi, String sifre) {
        super(ad, soyad, kAdi, sifre);
    }

    @Override
    public String getRol() {
        return "Müşteri";
    }
}
