package com.example.proje;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.image.Image;

import java.io.IOException;

public class GirisEkraniApplication extends Application {
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(GirisEkraniApplication.class.getResource("Giris_Ekrani.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        //logo ekler
        Image icon = new Image(GirisEkraniApplication.class.getResourceAsStream("logoJava.jpg"));
        stage.getIcons().add(icon);
        stage.setTitle("Mavi Restoran");
        //ekran büyütmeyi engeller
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) {
        launch();
    }
}
