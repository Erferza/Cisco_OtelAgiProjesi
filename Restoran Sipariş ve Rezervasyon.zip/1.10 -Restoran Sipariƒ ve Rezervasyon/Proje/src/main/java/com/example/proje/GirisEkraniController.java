package com.example.proje;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class GirisEkraniController extends UyariGostermeSayfaYukleme {

    @FXML
    private TextField kAdiText; //Kullanıcı ad text field
    @FXML
    private PasswordField sifrePw; //Şifre password field
    @FXML
    private Button girisBtn; // Giriş olma buton
    @FXML
    private Button kayitBtn; //Kayıt olma buton
    @FXML
    private Label bosLabel;  //Kullanıcı adı için hata mesajı gösteren etiket
    @FXML
    private Label bosLabel2; //Şifre için hata mesajı gösteren etiket

    public GirisEkraniController() { //Önceden kullanıcı ekleme
        //Kullanıcı listesine admin ve müşteri türünden örnek kullanıcılar ekleniyor
        Kullanicilar.kullanicilar.add(new Admin("admin", "admin", "admin", "admin"));
        Kullanicilar.kullanicilar.add(new Musteri("Kullanici", "Kullanici", "kullanici", "1234"));
    }

    @FXML
    private void onGirisBtnClicked(){
        String kullaniciAdi = kAdiText.getText(); //Kullanıcı adı metni alınıyor
        String sifre = sifrePw.getText(); //Şifre metni alınıyor
        boolean girisBasarili = false; //Girişin başarılı olup olmadığını kontrol eden değişken
        Kullanicilar girisYapanKullanici = null; //Giriş yapan kullanıcıyı tutan değişken


        //Kullanıcı doğrulama
        for (Kullanicilar kullanici : Kullanicilar.kullanicilar) {
            if (kullanici.getkAdi().equals(kullaniciAdi) && kullanici.getSifre().equals(sifre)) {
                girisBasarili = true;
                girisYapanKullanici = kullanici;
                break;
            }
        }

        if (girisBasarili) {
            if (girisYapanKullanici.getRol().equals("Admin")) {
                //Admin için farklı bir sahne yüklenir
                sayfaYukleme("AdminAnaSayfa.fxml",girisBtn);
            } else {
                // Müşteri için farklı bir sahne yüklenir
                sayfaYukleme("Hos_Geldin.fxml",girisBtn);
            }
        } else {
            //Giriş başarısızsa hata mesajları gösterilir
            boolean kSifrebool = false;
            for (Kullanicilar kullanici : Kullanicilar.kullanicilar) { //Kullanıcı adı doğru, ancak şifre yanlış mı kontrolü
                if (kullanici.getkAdi().equals(kullaniciAdi) && !kullanici.getSifre().equals(sifre)) {
                    kSifrebool = true;//Şifre yanlışsa
                    break;
                }
            }
            if (kSifrebool) {//Şifre yanlışsa hata mesajı gösterilir
                uyariGoster("Hatalı Şifre", "Şifre hatalı!",2);
            } else {//Kullanıcı bulunamadıysa hata mesajı gösterilir
                uyariGoster("Hesap Bulunamadı", "Kullanıcı bulunamadı, kayıt olunuz.",2);
            }
        }
    }

    @FXML
    private void onKayitBtnClicked() {//Kayıt olma butonuna tıklanıldığında çalışır.
        sayfaYukleme("Kayit.fxml",kayitBtn);
    }

    @FXML
    private void onkAdiTextChanged() {//Kullanıcı adı alanındaki değişiklikleri kontrol eden metot ve hata mesajı gösterir.
        if (kAdiText.getText().isEmpty()) {
            bosLabel.setText("Kullanıcı Adı boş bırakılamaz");
            girisBtn.setDisable(true);
        } else if (sifrePw.getText().isEmpty()) {
            bosLabel.setText("");
            girisBtn.setDisable(true);
        } else {
            girisBtn.setDisable(false);
            bosLabel.setText("");
        }
    }

    @FXML
    private void onSifreTextChanged() {//Şifre alanındaki değişiklikleri kontrol eden metot ve hata mesajı gösterir.
        if (sifrePw.getText().isEmpty()) {
            bosLabel2.setText("Şifre boş bırakılamaz");
            girisBtn.setDisable(true);
        } else if (kAdiText.getText().isEmpty()) {
            bosLabel.setText("");
            girisBtn.setDisable(true);
        } else {
            girisBtn.setDisable(false);
            bosLabel2.setText("");
        }
    }

}
