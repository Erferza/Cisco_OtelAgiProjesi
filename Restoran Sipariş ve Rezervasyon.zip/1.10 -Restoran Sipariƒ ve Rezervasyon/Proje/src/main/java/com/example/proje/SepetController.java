package com.example.proje;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class SepetController extends Sepet {

    @FXML
    private TableView<Menu> sepetTableView; // Sepetteki ürünlerin listelendiği tablo.

    @FXML
    private TableColumn<Menu, String> isimColumn; // Tablo içinde ürün adını gösteren sütun.

    @FXML
    private TableColumn<Menu, Integer> adetColumn; // Tablo içinde ürün adedini gösteren sütun.

    @FXML
    private TableColumn<Menu, Double> fiyatColumn; // Tablo içinde ürün fiyatını gösteren sütun.

    @FXML
    private Button silButton; // Seçili ürünü silmek için kullanılan buton.

    @FXML
    private Button siparisTamamlamaButton; //Siparişi tamamlayarak ödeme ekranına geçmek için kullanılan buton.

    @FXML
    private ImageView geriButon; // Önceki sayfaya dönmek için kullanılan buton

    @FXML
    private Button CikisBtn; // Oturum kapatmayı sağlayan buton

    @FXML
    public void initialize() { // Ekran yüklendiğinde varsayılan ayarların yapılması için kullanılan yöntem.
        //TableView sütunlarını veri ile bağlama
        isimColumn.setCellValueFactory(new PropertyValueFactory<>("urunAdi")); // Ürün adını göstermek için bağlama.
        adetColumn.setCellValueFactory(new PropertyValueFactory<>("adet")); // Ürün adedini göstermek için bağlama.
        fiyatColumn.setCellValueFactory(new PropertyValueFactory<>("fiyat")); // Ürün fiyatını göstermek için bağlama.

        //Tabloyu sepet listesindeki ürünlerle doldurur.
        sepetTableView.setItems(getSepetListesi());

        //Sil butonunun seçili bir ürün olmadığında devre dışı olmasını sağlar.
        silButton.disableProperty().bind(sepetTableView.getSelectionModel().selectedItemProperty().isNull());
    }

    @FXML
    private void sil() { //Tablo üzerinde seçili olan ürünü sepetten siler.
        Menu seciliUrun = sepetTableView.getSelectionModel().getSelectedItem(); //Tablo üzerinden seçili ürünü alır.
        if (seciliUrun != null) {
            urunSil(seciliUrun); // Sepet sınıfındaki urunSil metodunu çağırarak ürünü sepetten kaldırır.
            sepetTableView.refresh(); // Tabloyu günceller.
        }
    }

    @FXML
    private void onGeriButonClicked() {
        sayfaYukleme("Siparis.fxml", geriButon);
    }

    @FXML
    private void onSiparisTamamlaButonClicked() {
        sayfaYukleme("Adres_Odeme.fxml", siparisTamamlamaButton, getGenelToplamFiyat());

    }

    @FXML
    private void onCikisBtnClicked() {
        sayfaYukleme("Giris_Ekrani.fxml", CikisBtn);
    }
}
