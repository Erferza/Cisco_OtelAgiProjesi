package com.example.proje;

class Admin extends Kullanicilar {

    public Admin(String ad, String soyad, String kAdi, String sifre) {
        super(ad, soyad, kAdi, sifre); //Kullanıcı abstract sınıfından geliyor.
    }

    @Override
    public String getRol() {

        return "Admin"; //Girilen kullanıcı girişinine göre rol döndürür.
    }
}