package com.example.proje;

public class Menu {

    private String urunAdi;
    private int adet;
    private double fiyat;

    public Menu(String urunAdi, int adet, double fiyat) {
        this.urunAdi = urunAdi;
        this.adet = adet;
        this.fiyat = fiyat;
    }


    public String getUrunAdi() {
        return urunAdi;
    }

    public int getAdet() {
        return adet;
    }

    public double getFiyat() {
        return fiyat;
    }

    public void setUrunAdi(String urunAdi) {
        this.urunAdi = urunAdi;
    }

    public void setAdet(int adet) {
        this.adet = adet;
    }

    public void setFiyat(double fiyat) {
        this.fiyat = fiyat;
    }



}


