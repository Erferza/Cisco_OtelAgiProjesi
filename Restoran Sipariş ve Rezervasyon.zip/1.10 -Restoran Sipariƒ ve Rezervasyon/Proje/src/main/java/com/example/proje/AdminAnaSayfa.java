package com.example.proje;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminAnaSayfa extends UyariGostermeSayfaYukleme {
    @FXML
    private Button YemekEklemeBtn; //Yemek Ekleme Butonu
    @FXML
    private Button IcecekEklemeBtn; // İçecek Ekleme Butonu
    @FXML
    private Button CikisBtn; //Oturum Kapatma Butonu


    @FXML //Yemek Ekleme Butonu tıklandığında yemek ekleme sayfasına giden metot.
    private void onYemekEkleBtnClicked(){
        sayfaYukleme("AdminYemekEklemeSayfa.fxml", YemekEklemeBtn);
    }

    @FXML//İçecek Ekleme Butonu tıklandığında içecek ekleme sayfasına giden metot.
    private void onIcecekEkleBtnClicked(){
        sayfaYukleme("AdminIcecekEklemeSayfa.fxml", IcecekEklemeBtn);
    }

    @FXML//Çıkış Butonu tıklandığında giriş sayfasına giden metot.
    private void onCikisBtnClicked(){
        sayfaYukleme("Giris_Ekrani.fxml", CikisBtn);
    }

}
