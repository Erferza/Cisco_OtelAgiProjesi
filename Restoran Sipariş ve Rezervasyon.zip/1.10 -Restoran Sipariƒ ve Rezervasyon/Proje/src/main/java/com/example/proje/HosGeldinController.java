package com.example.proje;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class HosGeldinController extends UyariGostermeSayfaYukleme {
    @FXML
    private Button siparisBtn; //Sipariş sayfasına gitme buton
    @FXML
    private Button rezervasyonBtn; //Rezervasyon sayfasına gitme butonu
    @FXML
    private Button CikisBtn; //Oturum Kapatma Butonu
    @FXML
    private void onSiparisBtnClicked(){ //Şipariş sayfasına gitme butonuna tıklanıldığında çalışan metot. Sipariş sayfasına gider.
        sayfaYukleme("Siparis.fxml",siparisBtn);
    }
    @FXML
    private void onRezerveBtnClicked(){ //Rezervasyon sayfasına gitme butonuna tıklanıldığında çalışan metot. Sipariş sayfasına gider.
        sayfaYukleme("Rezervasyon.fxml",rezervasyonBtn);
    }
    @FXML
    private void onCikisBtnClicked() { //Çıkış Butonu tıklandığında giriş sayfasına giden metot.
        sayfaYukleme("Giris_Ekrani.fxml",CikisBtn);
    }

}