package com.example.proje;

public interface IUrun {
    String getIsim();
    double getFiyat();
}
