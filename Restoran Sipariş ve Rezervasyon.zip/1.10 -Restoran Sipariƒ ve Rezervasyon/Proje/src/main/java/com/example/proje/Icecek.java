package com.example.proje;

public class Icecek implements IUrun {
    private String isim; //İçecek isim
    private double fiyat; //İçecek fiyat

    public Icecek(String isim, double fiyat) {
        this.isim = isim;
        this.fiyat = fiyat;
    }

    @Override
    public String getIsim() {//İçeceğin ismini döndürür (Urun arayüzünden gelen metot)
        return isim;
    }

    @Override
    public double getFiyat() {//İçeceğin fiyatını döndürür (Urun arayüzünden gelen metot)
        return fiyat;
    }

    @Override
    public String toString() {//İçeceği string olarak ifade eder. Checkboxa yazdırır.
        return isim + " - " + fiyat + " TL";
    }
}
