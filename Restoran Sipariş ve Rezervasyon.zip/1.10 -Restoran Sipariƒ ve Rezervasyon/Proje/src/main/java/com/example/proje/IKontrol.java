package com.example.proje;

public interface IKontrol {
    boolean bosluk_hata_kontrol();
}
