package com.example.proje;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

import java.io.IOException;

public class AdminYemekEklemeSayfaController extends UyariGostermeSayfaYukleme implements IUrunlerEkleme {
    @FXML
    private TextField YemekAd; //Yazılan yemek adın texti
    @FXML
    private TextField YemekFiyat; //Yazılan yemeğin fiyat texti
    @FXML
    private Button YemekEklemeBtn; //Yemek Ekleme Butonu
    @FXML
    private Button CikisBtn; //Oturum Kapatma Butonu
    @FXML
    private ImageView geriButon; //Admin ana sayfaya dönme image
    @FXML
    private Button IcecekSayfaBtn; //İçecek sayfasına dönme butonu

    //Girilen yemeklerin listesi (ObservableList)
    private static final ObservableList<Yemek> yemekListesi = FXCollections.observableArrayList();
    @FXML //Yemek ekleme butonuna tıklayınca yemek ekleyen metot
    private void onYemekEklemeBtnClicked() {
        String yemekAdi = YemekAd.getText();//Yemek adı alıyor
        String yemekFiyati = YemekFiyat.getText();//Yemek fiyat alıyor
        if (yemekAdi.isEmpty() || yemekFiyati.isEmpty()) {
            //Eğer textfieldler boşsa hata veriyor
            uyariGoster("Hata", "Lütfen tüm alanları doldurunuz!",2);
            return;
        }

        try {
            double fiyat = Double.parseDouble(yemekFiyati); //stringi double a çeviriyor.
            urunEkle(yemekAdi, fiyat);//urunu ekliyor
            uyariGoster("Başarılı", "Yemek başarıyla eklendi!",1);//Her şey düzgünse Başarılı mesajı veriyor.
            IUrun yemek = new Icecek(yemekAdi, fiyat);//Polimorfizm. Konsolda yazdırma
            System.out.println(yemek.getIsim() + " : " + yemek.getFiyat() + " olarak ayarlanmıştır.");
            //Değer girildikten textfieldlar siliniyor.
            YemekAd.clear();
            YemekFiyat.clear();
        } catch (NumberFormatException e) {
            //Harf girerse bu catche atıyor atıyor.
            uyariGoster("Hata", "Fiyat alanına geçerli bir sayı giriniz!",2);
        }
    }

    //Yeni bir yemek eklemek için kullanılan metot (Interface üzerinden override ediliyor)
    @Override
    public void urunEkle(String ad, double fiyat) {
        yemekListesi.add(new Yemek(ad, fiyat));
    }

    //Yemek listesini döndüren metot
    public static ObservableList<Yemek> getYemekListesi() {
        return yemekListesi;
    }

    @FXML
    private void onIcecekSayfaButonClicked() {//İçecek Ekleme Butonu tıklandığında yemek ekleme sayfasına giden metot.
        sayfaYukleme("AdminIcecekEklemeSayfa.fxml",IcecekSayfaBtn);
    }
    @FXML
    private void onCikisBtnClicked() throws IOException {//Çıkış Butonu tıklandığında giriş sayfasına giden metot.
        sayfaYukleme("Giris_Ekrani.fxml",CikisBtn);
    }
    @FXML
    private void onGeriButonClicked() {//Geri image tıklandığında bir admin ana sayfaya giden metot.
        sayfaYukleme("GAdminAnaSayfa.fxml",geriButon);
    }
}
